def print_items(n):
    for i in range(n):
        print(i)

print_items(10)

           
              
                  
                  






