def add_items(n):
    return n + n + n
 

print add_items(10)